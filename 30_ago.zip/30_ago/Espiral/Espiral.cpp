#include <iostream>	// Biblioteca donde se encuentran las funciones "cin" y "cout"
#include <cstring>	// usaremos la función "strcpy()" que se encuantra en string.h
#include <cstdlib>
using namespace std;

void llenaArreglo(int* A,int x);
void imprimirArreglo(int* A, int x);
void intercambia(int* A, int* B, int x);

void llenaMatriz(int** A, int n, int m);
void imprimeEspiral(int** A, int inicio, int n, int m);

int main(int argc, char **argv)
{
	int n,m;
	cout << "Ingrese un tamaño: \n";
	cin >> n;
	int** A = new int*[n];
	for(int i = 0; i<n; i++)
	{
		A[i] = new int[n];
	}

	cout << "Ingrese otro tamaño:\n";
	cin >> m;

	llenaMatriz(A,n,m);
	
	for(int i = 0; i<n; i++)
	{
		for(int j = 0; j <m; j++)
		{
			cout << A[i][j] << " ";
		}
		cout << endl << endl;
	}

	imprimeEspiral(A,0,n,m);

	return EXIT_SUCCESS;
}




void llenaMatriz(int** A, int n, int m)
{
	for(int i = 0; i<n; i++)
	{
		for(int j = 0; j <m; j++)
		{
			A[i][j] = 10 + rand()%(20 + 1 - 10); //MIN + rand()%(MAX + 1 - MIN)
		}
	}
		
}

void imprimeEspiral(int** A, int inicio, int n, int m)
{
	
	int i = inicio;
	int j = inicio;
	for (; j< inicio + m; j++)
	{
		cout << A[i][j] << " ";
	}
	j--;
	for(i++; i< inicio + n ; i++)
	{
		cout << A[i][j] << " ";
	}
	i--;

	if (n > 1 && m > 1)
	{
		for(j--; j>= inicio; j--)
		{
			cout << A[i][j] << " ";
		}
		j++;
		for(i--; i>inicio; i--)
		{
			cout << A[i][j] << " ";
		}

		imprimeEspiral(A,inicio + 1, n-2, m-2);
	}
		
}



void llenaArreglo(int* A,int x)
{
	for(int i = 0; i < x; i++)
	{
		A[i] = 1 + rand()%(100 + 1 - 1);
	}
}

void imprimirArreglo(int* A, int x)
{
	for(int i = 0; i < x; i++)
	{
		cout << A[i] << " ";
	}
	cout << endl;
}


//intercambia los elementos impares de una matriz
void intercambia(int* A, int* B, int x)
{
	int aux;
	for(int i = 0; i < x; i++)
	{
		if(i%2 == 1)
		{
			aux = A[i];
			A[i] = B[i];
			B[i] = aux;
		}
	}
}


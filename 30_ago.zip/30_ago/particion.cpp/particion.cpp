
#include <iostream>	
#include <cstring>	
using namespace std;
void llenaArreglo(int* A, int x);
int posicionFinal(int* A, int n, int x);
void mayoresYMenores(int* A, int p, int k, int n);
void swap(int* A, int a, int b);
void imprimirArreglo(int* A, int n);


#define MIN 1
#define MAX 100

int main(int argc, char **argv){

	int n,k,p,x;
	cout << "Ingrese un tamano para el arreglo: \n";
	cin >> n;

	//Creamos y llenamos el arreglo
	int* A = new int[n];
	llenaArreglo(A,n);
	imprimirArreglo(A,n);

	cout << "Ingrese un numero p para la posicion A[p] del arreglo: \n";
	cin >> p;
	while (p < 0 || p >= n)
	{
		cout << "ERROR!! p se encuentra fuera de los limites.\n";
		cout << "Ingrese un numero p para la posicion A[p] del arreglo: \n";
		cin >> p;
	}

	x = A[p];
	k = posicionFinal(A,n,x);
	cout << "Si A estuviese ordenado, x estaria en la posicion A[" << k << "]\n";

	mayoresYMenores(A,p,k,n);
	imprimirArreglo(A,n);

	cout << "Programa terminado exitosamente !!" << endl;
	return EXIT_SUCCESS; // 8. código de éxito, recuerde que definimos que el main() retorna un entero
}

void llenaArreglo(int* A,int x)
{
	for(int i = 0; i < x; i++)
	{
		A[i] = 1 + rand()%(100 + 1 - 1);
	}
}


//el algoritmo no pide ordenar, pide encontrar la posicion del elemento si el arreglo estuviese ordenado
//este algoritmo cuenta cuantos numeros menores que x hay(en otras palabras, cuantos numeros hay antes que x)
//ese numero sera la posicion de x.
int posicionFinal(int* A, int n, int x)
{
	int k = 0;
	for(int i = 0; i < n; i++) //nota: la condicion tambien puede ser (i < n - 1) ¿por que crees?
	{
		if (A[i] < x)
		{
			k++;
		}
	}
	return k;
}

//primero se nos pide colocar la x en su posicion original
//el algoritmo ira chequeando por ambos lados de x, e ira intercambiando los elementos que no correspondan
//pero: este algoritmo podria no chequear el arreglol entero ya que si a un lado de x hay menos numeros, podria el primer while antes de terminar con el otro lado
//¿porqu funciona entonces si no estamos chequenado todos los elementos? (pista: si lo hicimos ¿cuando?)
void mayoresYMenores(int* A, int p, int k, int n)
{
	swap(A,p,k); //intercambia el elemento de la posicion p con el de la k (osea posiciona x en su lugar)
	int x = A[k];//recordar que ahora que cambiamos p <-> k, x se encuentra en A[k]
	int i = 0;
	int j = n-1;
	while (i != k && j != k)
	{
		while(A[i] < x) i++;
		while(A[j] > x) j--;
		swap(A,i,j);
	}
}

//Funcion auxiliar para intercambiar elementos entre si
void swap(int* A, int a, int b)
{
	int aux = A[a];
	A[a] = A[b];
	A[b] = aux;
}

void imprimirArreglo(int* A, int n)
{
	for(int i = 0; i < n; i++)
	{
		cout << A[i] << " ";
	}
	cout << endl;
}


//interpreten el algoritmo a ver si pueden decifrarlo en su totalidad, trate dejarlo lo mas claro posible. sin embargo 
//podrian haber confusiones. cualquier cosa no duden en escribirme. 
//el algoritmo mayoresYMenores es eficiente en sentido que solo necesita recorrer el arreglo una sola vez
//Fe de erratas: el ejercicio solicitaba dejar los numeros iguales a la izquierda, este algoritmo los deja a la derecha.
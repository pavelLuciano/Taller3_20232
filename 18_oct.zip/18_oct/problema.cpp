#include <iostream>
using namespace std;


#define MIN 0
#define MAX 99

void creaFila();
void agregaRonda();
void cambiaInicio();
void imprimeRonda();

struct nodoEstructura(){
	int valor;
	nodoEstructura* prev;
	nodoEstructura* next;
}typedef struct nodoEstructura nd;

int main(int argc, char **argv)
{
	nd* Ronda;
	nd *Fila1, *Fila2;
	creaFila(Fila1, 8);
	agregaRonda(Fila1);
	imprimeRonda(Ronda);
	creaFila(Fila2,6);
	imprimeRonda(Ronda);


}





/*
struct nodo{
	int val;
	nodo *next;
};


void mifunc(nodo *M)
{
	cout << M->val << endl;
	M->val = 5;
	cout << M->val << endl;
}

void nuevoNodo(nodo *A, int n)
{
	nodo* p = A;
	nodo* nuevo = new nodo();
	nuevo -> val = n;
	while (p->next != nullptr) p = p->next;
	p -> next = nuevo;
}

void print(nodo *L)
{
	nodo *p = L;
	while (p != nullptr) 
	{
		cout << p->val << " ";
		p = p->next;
	}
	cout << "\n";
	
}

void nuevoNodoPrincipio(nodo* &A, int n)
{
	
	nodo *nuevo = new nodo();
	nuevo -> val = n;
	nuevo -> next = A;
	A = nuevo;

}



int main(int argc, char **argv)
{
	nodo L = {3, NULL};
	nodo *S = &L;
	mifunc(&L);
	nuevoNodo(S,11);
	nuevoNodoPrincipio(S,13);
	print(S);
}

*/
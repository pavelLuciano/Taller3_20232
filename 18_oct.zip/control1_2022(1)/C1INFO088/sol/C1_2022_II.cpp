#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;

#define GAP 10

struct myStruct {
	int corr;
	int val;
	myStruct *next;
};typedef struct myStruct dato;

vector<dato*> createSampling(dato *l, int n, int b);
int mixSearchSampling(vector<dato*> &S, int x, int b);
void anadirNElementos(dato **l, int n, int i,int valPrev);

// MÉTODOS YA CODIFICADOS Y LISTOS PARA UTILIZAR
int binarySearchSampling(vector<dato*> &S, int x);
void printLista(dato *l);
void printArray(vector<dato *> &S);

int main(int argc, char **argv){
	if(argc != 3){
		cout << "Error. Debe ejecutarse como ./problema n b" << endl;
		exit(EXIT_FAILURE);
	}

	int n = atoi(argv[1]);
	int b = atoi(argv[2]);
	int x;

	
	dato* l; 
	anadirNElementos(&l,n,0,0);
	vector<dato*> s = createSampling(l,n,b);

	printLista(l);
	printArray(s);

	int a ;
	cout<<"Ingrese entero a buscar (negativo para finalizar), ";
	do
	{	
		cout<<"x = ";
		cin >> x;

		a = mixSearchSampling(s,x,b);
		if (a>=0) cout <<" Encontrado en corr = "<<a << endl;
		else cout << "no encontrado" << endl; 
	}while (x>=0);




	cout << "### Fin Control 1 ###" << endl;
	return EXIT_SUCCESS;
}

vector<dato*> createSampling(dato *l, int n, int b)
{
	int tam = n/b;
	vector <dato*> v(tam);
	dato* p = l;
	for (int i = 0; i<tam; i++)
	{
		v[i] = p;
		for(int j = 0; j < b; j++)
		{
			p = p->next;
		}
	}
	return v;
}
	
//añade un dato
void anadirNElementos(dato **l, int n,int i, int valPrev)
{
	dato *nuevo = new dato;
	nuevo->val = valPrev + 1 + rand()%(GAP+1);
	nuevo->corr = i;
	nuevo->next = NULL;

	cout << "Aniadiendo a la cola el nodo con val = " << nuevo -> val << endl;
	*l = nuevo;
	if (n>1) anadirNElementos(&((*l)->next), n-1, i+1,((*l)->val));
}


// devuelve el correlativo del nodo cuyo val es x, o -1 si no existe
int mixSearchSampling(vector<dato*> &S, int x, int b)
{
	int m = binarySearchSampling(S,x);
	dato* p;
	if (m < 0) cout << "No hay busqueda  (x < S[0]->val) -->"<<endl;
	else
	{
		cout << "comenzando en nodo S["<<m<<"] con ("<< S[m]->corr <<","<< S[m]->val <<") -->";
		p = S[m];
		for(int i = m; i < (m+1)*b || p == nullptr; i++)
		{
			if (p->val == x) return p->corr;
			p = p -> next;
		}
		
	}
	return -1;

}


// ===========================================================================================
// MÉTODOS LISTOS PARA UTILIZAR
// ===========================================================================================
// Búsqueda binaria de x en S[0...S.size()-1], tal que todos los elementos de S son distintos:
// 	return -1, Si x < S[0]->val
// 	return S.size()-1, Si S[S.size()-1]->val <= x
// 	return m, Si S[m]->val <= x < S[m+1]->val
int binarySearchSampling(vector<dato*> &S, int x){
	int l, r, m, u=S.size();
	
	if (x < S[0]->val)
		return -1;
	if (S[u-1]->val <= x)
		return u-1;	
		
	l=0, r=u-1, m=r/2;
	while(l<=r){
		if (S[m]->val <= x && x < S[m+1]->val)
			return m;
		else{
			if (x < S[m]->val)
				r=m-1;
			else
				l=m+1;
		}
		m=(l+r)/2;
	}
	return m;
}

void printArray(vector <dato*> &S){
	cout << "Vector S = " << endl;
	for(unsigned int i=0; i<S.size(); i++)
		cout << "(" << S[i]->corr << ", " << S[i]->val << ") ";
	cout << endl;
}

void printLista(dato* l){
	dato *p = l;
	cout << "Lista :" << endl;
	while (p != nullptr){
		cout << "(" << p->corr << ", " << p->val << ") ";
		p = p->next;
	}
	cout << endl;
}




/*
================================
MÉTODOS DESARROLLADOS EN CLASES
================================

// añade un nodo al inicio de la lista
void appendToListL(nodo **l, int num){
	nodo *nuevo = new nodo;
	nuevo->val = num;
	nuevo->next = *l;
	*l = nuevo;
}

// añade un nodo al final de la lista
void appendToListR(nodo **l, int num){
	nodo *nuevo = new nodo;
	nuevo->val = num;
	nuevo->next = NULL;

	cout << "Aniadiendo a la cola el nodo con val = " << num << endl;
	if (*l == nullptr)
		*l = nuevo;
	else{
		nodo *p = *l;
		while (p->next != nullptr)
			p = p->next;

		p->next = nuevo;
	}
}
*/


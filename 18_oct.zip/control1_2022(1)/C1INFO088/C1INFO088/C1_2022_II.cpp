#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;

#define GAP 10

struct myStruct {
	int corr;
	int val;
	myStruct *next;
};typedef struct myStruct dato;

vector<dato*> createSampling(dato *l, int n, int b);
int mixSearchSampling(vector<dato*> &S, int x);

// MÉTODOS YA CODIFICADOS Y LISTOS PARA UTILIZAR
int binarySearchSampling(vector<dato*> &S, int x);
void printLista(dato *l);
void printArray(vector<dato *> &S);

int main(int argc, char **argv){
	if(argc != 3){
		cout << "Error. Debe ejecutarse como ./problema n b" << endl;
		exit(EXIT_FAILURE);
	}
	
	
	cout << "### Fin Control 1 ###" << endl;
	return EXIT_SUCCESS;
}

vector<dato*> createSampling(dato *l, int n, int b){
	
}

// devuelve el correlativo del nodo cuyo val es x, o -1 si no existe
int mixSearchSampling(vector<dato*> &S, int x){
	
}


// ===========================================================================================
// MÉTODOS LISTOS PARA UTILIZAR
// ===========================================================================================
// Búsqueda binaria de x en S[0...S.size()-1], tal que todos los elementos de S son distintos:
// 	return -1, Si x < S[0]->val
// 	return S.size()-1, Si S[S.size()-1]->val <= x
// 	return m, Si S[m]->val <= x < S[m+1]->val
int binarySearchSampling(vector<dato*> &S, int x){
	int l, r, m, u=S.size();
	
	if (x < S[0]->val)
		return -1;
	if (S[u-1]->val <= x)
		return u-1;	
		
	l=0, r=u-1, m=r/2;
	while(l<=r){
		if (S[m]->val <= x && x < S[m+1]->val)
			return m;
		else{
			if (x < S[m]->val)
				r=m-1;
			else
				l=m+1;
		}
		m=(l+r)/2;
	}
	return m;
}

void printArray(vector <dato*> &S){
	cout << "Vector S = " << endl;
	for(unsigned int i=0; i<S.size(); i++)
		cout << "(" << S[i]->corr << ", " << S[i]->val << ") ";
	cout << endl;
}

void printLista(dato* l){
	dato *p = l;
	cout << "Lista :" << endl;
	while (p != nullptr){
		cout << "(" << p->corr << ", " << p->val << ") ";
		p = p->next;
	}
	cout << endl;
}

/*
================================
MÉTODOS DESARROLLADOS EN CLASES
================================

// añade un nodo al inicio de la lista
void appendToListL(nodo **l, int num){
	nodo *nuevo = new nodo;
	nuevo->val = num;
	nuevo->next = *l;
	*l = nuevo;
}

// añade un nodo al final de la lista
void appendToListR(nodo **l, int num){
	nodo *nuevo = new nodo;
	nuevo->val = num;
	nuevo->next = NULL;

	cout << "Aniadiendo a la cola el nodo con val = " << num << endl;
	if (*l == nullptr)
		*l = nuevo;
	else{
		nodo *p = *l;
		while (p->next != nullptr)
			p = p->next;

		p->next = nuevo;
	}
}
*/


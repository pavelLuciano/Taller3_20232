#include <iostream>	
#include <fstream>
#include <cstring>	
#include <cstdlib>
using namespace std;

#define MAX_VAL 999
#define MIN_VAL 100

struct nodoMatriz{
	int valor;
	int i;
	int j;
	nodoMatriz* up;
	nodoMatriz* down;
	nodoMatriz*	right;
	nodoMatriz* left;
};
typedef struct nodoMatriz nMat;

//FUNCIONES:
void agregarNodo(nMat** M, int num);
void creaMatriz(nMat** M, int n, int m);
void agregaFilaAbajo(nMat** M);
void agregaColumnaDer(nMat** M);
void agregaFilaArriba(nMat** M);
void agregaColumnaIzq(nMat** M);

void incrementaFilas(nMat** M);
void incrementaColumnas(nMat** M);

void printMat(nMat *M);

int main(int argc, char **argv)
{
	int n, m;
	if(argc != 3){
		cout << "Error. Debe ejecutarse como ./matriz n m" << endl;
		exit(EXIT_FAILURE);
	}

	n = atoi(argv[1]);//filas
	m = atoi(argv[2]);//columnas

	//Creamos la matriz
	nMat* Matriz = NULL;
	creaMatriz(&Matriz, n, m);
	printMat(Matriz);

	agregaColumnaDer(&Matriz);
	agregaFilaArriba(&Matriz);
	agregaColumnaIzq(&Matriz);
	printMat(Matriz);

	cout << "FIN DEL PROGRAMA!\n";
}

void creaMatriz(nMat** M, int n , int m)
{

	
}

void agregaFilaAbajo(nMat** M)
{
	
}

//revisar
void agregaColumnaDer(nMat** M)
{
	
}

void agregaFilaArriba(nMat** M)
{
	
}

void agregaColumnaIzq(nMat** M)
{
	
}

void incrementaFilas(nMat** M)
{
	
}
void incrementaColumnas(nMat** M)
{
	
}

void printMat(nMat* M)
{
	nMat *p, *q;
	p = M;
	while(p != nullptr)
	{
		q = p;
		while(q != nullptr)
		{
			cout << (q->valor) <<" ";
			q = q->right;
		}
		cout << endl;;
		p = p->down;
	}
}

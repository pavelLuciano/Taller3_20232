#include <iostream>

/*
    El objetivo del ejercicio es crear un arbol binario para traducir un codigo.
    Pimero asignar el codigo:
    Ej: 
                    raiz
                    /  \
                   0    1
                  /      \
                NULL    NULL
                / \      /  \
               0   1    0    1
              /    \    /     \
              h     l   a      o
    
    en este ejemplo traducir "00110110" se traduciria como: "hola"
    (Note que el nodo no contiene elementos si no hasta que sea una hoja, 
    el cero y el uno se traducen como el nodo izquierdo y derecho)

    en este caso de 4 letras. Utilizar la misma logica para crear un arbol para 
    traducir las 27 letras del abecedario mas 5 caracteres mas: espacio, punto, coma , ? y !
    (en ese orden) para completar un total de 32.
    ¿Por que 32?

    ayuda:
    "a": 00000
    "b": 00001
    "c": 00010
    "d": 00011
    "e": 00100
    "f": 00101
    "g": 00110
    "h": 00111
    "y": 01000
    "j": 01001
    "k": 01010
    "l": 01011
    "m": 01100
    "n": 01101
    "ñ": 01110
    "o": 01111
    "p": 10000
    "q": 10001
    "r": 10010
    "s": 10011
    "t": 10100
    "u": 10101
    "v": 10110
    "w": 10111
    "x": 11000
    "y": 11001
    "z": 11010
    " ": 11011
    ";": 11100
    ".": 11101
    "?": 11110
    "!": 11111

Finalmente traduzca este mensaje con ayuda de su arbol y la funcion leecaracter
0010100000011001001100100011010100110011001100100011100000110111011010010110010001100100011010100110010001100110011001000111000001100000110111101110010011001000110001001101000110000100110100001101010011100100110010001100110011001100011010000110111001110010

*/

struct nodo
{
    char caracter;
    nodo* zero;
    nodo* one;
};

void agregaCaracter(nodo *A, char caracter);
char leeCaracter(bool* A);
void creaArbol(nodo **A);


int main()
{
    nodo* arbol;   
    return 0;
}
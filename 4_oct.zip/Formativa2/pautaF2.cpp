#include <iostream>
#include <cstdlib>
using namespace std;

#define INC 10

struct nodeList {
	int val;
	nodeList* next;
};
typedef struct nodeList nodo;

nodo* creaLista(int len, int gap);
void uneListas(nodo **l1, int n, nodo *l2, int m);
void appendToListL(nodo **l, int num);
void appendToListR(nodo **l, int num);
void printList(nodo *l);

int main(int argc, char **argv){	
	if(argc != 3){
		cout << "Error. Debe ejecutarse como ./problema n m" << endl;
		exit(EXIT_FAILURE);
	}
	int n = atoi(argv[1]);
	int m = atoi(argv[2]);
	nodo *l1 = NULL, *l2 = NULL;
	
	l1 = creaLista(n, 4*INC);
	cout << "Lista 1 = ";
	printList(l1);
	
	l2 = creaLista(m, INC);
	cout << "Lista 2 = ";
	printList(l2);

	cout << "Une listas = ";
	uneListas(&l1, n, l2, m);
	printList(l1);

	cout << "### Fin Problema ###" << endl;
	return EXIT_SUCCESS;
}

// crea una lista creciente con incrementeos positivos y <= gap, de n nodos
nodo* creaLista(int len, int gap){
	nodo *l = NULL;
	int i, x = 1+rand()%gap;
	
	appendToListR(&l, x);
	for(i=1; i<len; i++){
		x = x + 1 + rand()%gap;
		appendToListR(&l, x);
	}
	
	return l;
}

// añade todos los nodos de l2 en l1, por segmentos de nodos y no de uno en uno.
void uneListas(nodo **l1, int n, nodo *l2, int m){
	nodo *p, *q, *r;
	
	if(l2 == nullptr || m == 0)
		return;
	if(*l1 == nullptr || n == 0) {
		*l1 = l2;
		return;
	}
	
	//1- insertar nodos de l2 al inicio de l1:
	if((*l1)->val <= l2->val){
		p = *l1;
		q = l2;
	}else{
		p = l2;
		q = *l1;
		*l1 = p;
	}

	while(p!=nullptr && q!=nullptr){
			while(p->next != nullptr && p->next->val < q->val)
				p = p->next;
			r = p->next;
			p->next = q;
			p = q;
			q = r;
	}
}

// aniade un nodo al inicio de la lista
void appendToListL(nodo **l, int num){
	nodo *nuevo = new nodo;
	nuevo->val = num;
	nuevo->next = *l;
	*l = nuevo;
}

// aniade un nodo al final de la lista
void appendToListR(nodo **l, int num){
	nodo *nuevo = new nodo;
	nuevo->val = num;
	nuevo->next = NULL;

	if (*l == nullptr)
		*l = nuevo;
	else{
		nodo *p = *l;
		while (p->next != nullptr)
			p = p->next;

		p->next = nuevo;
	}
}


void printList(nodo *l){
	nodo *p = l;
	
	while(p != nullptr){
		cout << p->val << " ";
		p = p->next;
	}
	cout << endl;
}

#include <iostream>
#include <cstdlib>
using namespace std;

#define INC 10

struct nodeList {
	int val;
	nodeList* next;
};
typedef struct nodeList nodo;

nodo* creaLista(int len, int gap);
void uneListas(nodo **l1, int n, nodo *l2, int m);
void appendToListL(nodo **l, int num);
void appendToListR(nodo **l, int num);
void printList(nodo *l);

int main(int argc, char **argv){	
	if(argc != 3){
		cout << "Error. Debe ejecutarse como ./problema n m" << endl;
		exit(EXIT_FAILURE);
	}


	cout << "### Fin Problema ###" << endl;
	return EXIT_SUCCESS;
}

// crea una lista creciente con incrementeos positivos y <= gap, de n nodos
nodo* creaLista(int len, int gap){

}

// añade todos los nodos de l2 en l1, por segmentos de nodos y no de uno en uno.
void uneListas(nodo **l1, int n, nodo *l2, int m){

}

// aniade un nodo al inicio de la lista
void appendToListL(nodo **l, int num){
	nodo *nuevo = new nodo;
	nuevo->val = num;
	nuevo->next = *l;
	*l = nuevo;
}

// aniade un nodo al final de la lista
void appendToListR(nodo **l, int num){
	nodo *nuevo = new nodo;
	nuevo->val = num;
	nuevo->next = NULL;

	if (*l == nullptr)
		*l = nuevo;
	else{
		nodo *p = *l;
		while (p->next != nullptr)
			p = p->next;

		p->next = nuevo;
	}
}


void printList(nodo *l){
	nodo *p = l;
	
	while(p != nullptr){
		cout << p->val << " ";
		p = p->next;
	}
	cout << endl;
}

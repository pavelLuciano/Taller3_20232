#include <iostream>
#include <vector>
#include <cstdlib>
using namespace std;

#define MIN 100
#define MAX 999

struct Numero{
	bool grupoA;
	int valor;
};

vector<Number> createVector(int n, float pA);
void insertionSortGroupA(vector<Number> &v);
void imprimeVector(const vector<Number> &v);

int main(int argc, char **argv){	
	if(argc != 3)
	{
		cout << "Error. Debe ejecutarse como ./problema n p" << endl;
		exit(EXIT_FAILURE);
	}
	
	
	
	cout << "### Fin Problema ###" << endl;
	return EXIT_SUCCESS;
}

void insertionSort(vector<Number> &v){
	int i,j,key;

	for(i=1; i<v.size(); i++){
		key = v[i].val;
		j = i-1;
		while (j>=0 && v[j].val>key){
			v[j+1] = v[j];
			j--;
		}
		v[j+1].val = key;
	}
}

#include <iostream>
using namespace std;

#define MIN
#define MAX
#define LARGO_MIN
#define LARGA_MAX


void llenarArreglo(int *A, int n);
int mediana(int *A, int n);
void imprimeArreglo(int *A, int n);
void separar(int *B, int *C);

int main(int argc, char **argv){
	
	if (argc != 2)
	{
		cout << "Error, debe ejecutarse como ./problema n" << endl;
		exit(EXIT_FAILURE);
	}

	int *A;
	int n;
	llenarArreglo(A, n);
	cout << "La mediana es: "<< mediana(A, n) << endl;

	//PARTE 2
	int *B, *C;
	int n, m;

	llenarArreglo(B, n);
	llenarArreglo(C, m);
	separar(B, C);

	cout << "Arreglos separados: \n";
	imprimeArreglo(B, n);
	imprimeArreglo(C, m);

	return EXIT_SUCCESS;

}



#include <iostream>	
#include <cstring>
#include <cmath>
using namespace std;

int main(int argc, char **argv){
	
	int largo, n, m;
	int d_init, d_fin; //digito inicial y digito final

	if(argc != 2){
		cout << "Error. Debe ejecutarse como ./ejer6 n" << endl;
		exit(EXIT_FAILURE);
	}

	d_init = d_fin = 0;
	n = m = atoi(argv[1]);

	//esta linea chequea el largo del numero
	for (largo = 0; m > 0; m/=10, largo++);
	if(largo > 9)
	{
		cout << "numeros muy largos pueden causar problemas en datos tipo 'int', el algoritmo podria fallar\n¿Cómo lo solucionarias?\n";
		exit(EXIT_FAILURE);
	}


	//se tomaran el primer digito (d_init) y el ultimo digito (d_fin) y se compararan.
	//estos digitos se eliminan del numero y se repite hasta que el numero quede vacio o con solo un numero
	while(largo > 1 && d_init == d_fin)
	{
		largo--;
		d_init = n / pow(10,largo);
		d_fin = n % 10;
		n %= int(pow(10,largo));
		n /= 10;
		largo--;
	}
	
	if (d_init == d_fin) cout << "ES PALINDORMO\n";
	else cout << "NO ES PALINDROMO\n";
	
	//¿Se te ocurren mejores maneras de acerlo? ¡¡¡Prueba algún algoritmo diferente!!! :D
	//Intenta hacerlo con y sin datos "int".

	cout << "Programa terminado exitosamente !!" << endl;
	return EXIT_SUCCESS;
}
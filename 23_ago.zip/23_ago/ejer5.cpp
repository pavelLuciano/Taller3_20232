#include <iostream>	
#include <cstring>
#include <cmath>
using namespace std;

int main(int argc, char **argv){
	int n, m;
	int bin, bin2;

	if(argc != 2){
		cout << "Error. Debe ejecutarse como ./ejer5 n" << endl;
		exit(EXIT_FAILURE);
	}

	bin = bin2 = 0;
	n = m = atoi(argv[1]);

	//puse el algoritmo con un ciclo for y con un ciclo while para que se entendiera mejor

	cout << "El numero en binario es: \n";
	for(int i = 0; n > 0; i++, n/=2)
		bin += (n % 2) * pow(10,i);
	
	cout << bin << endl;


	cout << "(ciclo while) El numero en binario es: \n";
	int i = 0;
	while (m > 0)
	{
		bin2 += (m % 2) * pow(10,i);
		m/= 2;
		i++;
	}
	cout << bin2 << endl;

	cout << "Programa terminado exitosamente !!" << endl;
	return EXIT_SUCCESS;
}
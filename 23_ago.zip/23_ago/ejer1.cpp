#include <iostream>	
#include <cstring>	
using namespace std;

int main(int argc, char **argv){
	int men, med, may;
	int a, b ,c;

	if(argc != 4){
		cout << "Error. Debe ejecutarse como ./ejer1 a b c" << endl;
		exit(EXIT_FAILURE);
	}

	a = atoi(argv[1]);
	b = atoi(argv[2]);
	c = atoi(argv[3]);
	

	//ordenamos los dos primeros numeros para tener el primer par ordenado
	if (a <= b)
	{
		men = a;
		med = b;
	}
	else
	{
		men = b;
		med = a;
	}

	//Luego, ubicamos el tercer numero ante, en medio, o despues de esos dos numeros
	if (c < men)//es menor que el mas pequeno?
	{
		may = med;
		med = men;
		men = c;
	}
	else if (c < med)//sino, es menor que el siguiente?
	{
		may = med;
		med = c;
	}
	else //sino, solo puede ser mayor.
	{
		may = c;
	}
	//una vez asignados, se pueden imprimir en el orden que queramos 
	cout << "De menor a mayor:\n";
	cout << men << " " << med << " " << may << endl;
	cout << "Programa terminado exitosamente !!" << endl;
	return EXIT_SUCCESS;
}
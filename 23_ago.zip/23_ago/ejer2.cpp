#include <iostream>
#include <cstring>
#include <cmath> //con esto usaremos la funcion potencia
using namespace std;

int main(int argc, char **argv){
	int resto, cont;
	int n, m;

	if(argc != 2){
		cout << "Error. Debe ejecutarse como ./ejer2 n" << endl;
		exit(EXIT_FAILURE);
	}

	m = n = atoi(argv[1]);
	cont = 0;

	//imprimimos digito a digito de derecha a izquierda
	//el resto o modulo (%) de la division entera de diez sera siempre el ultimo digito, ej: "123 % 10 = 3"
	//n es un entero por lo que las divisiones con n SIEMPRE seran divisiones enteras, ej: "123 / 10 = 12"
	//con la variable "cont" contaremos cuantos digitos tiene el numero original, sera util para la seguda parta del ejercicio
	cout << "De izquierda a derecha: \n";
	while (n != 0)
	{
		resto = n % 10; 
		cout << resto << " ";
		n /= 10; //es lo mismo que "n = n/10"
		
		cont++; //es la mismo que "cont = cont + 1"
	}
	cout << endl;

	
	//imprimimos de derecha a izquierda
	//usaremos la misma variable "resto" para imprimirlo
	//iremos dividiendo en potencias de diez para obtener el primer digito
	cout << "De derecha a izquierda: \n";
	resto = 0;
	while (m != 0)
	{
		cont--;
		resto = m / pow(10, cont);
		cout << resto << " ";
		m = m % int(pow(10, cont)); //por como funciona el modulo(%), es necesario transformar la potencia a int
	}
	cout << endl;

	//pueden usar cualquiera de los dos metodos para almacenar digito a digito en un string y luego imprimirlo con un for


	cout << "Programa terminado exitosamente !!" << endl;
	return EXIT_SUCCESS;

}

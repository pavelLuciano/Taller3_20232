#include <iostream>	
#include <cstring>	
using namespace std;

int main(int argc, char **argv){
	
	cout << "Esto, si no entiendo mal, es muy parecido al ejercicio 2. Asi que me lo saltaré\n";

	return EXIT_SUCCESS;
}
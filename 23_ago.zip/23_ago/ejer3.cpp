#include <iostream>
#include <cstring>

using namespace std;

int main(int argc, char **argv){

	int l, r;

	if(argc != 3){
		cout << "Error. Debe ejecutarse como ./ejer3 l r" << endl;
		exit(EXIT_FAILURE);
	}

	l = atoi(argv[1]);
	r = atoi(argv[2]);
	
	if (r < l)
	{
		int aux = l; //esta variable "aux" solo existe en este contexto (dentro del if)
		l = r;
		r = aux;
	}


	//chequeamos que cada numero "i" entre "l" y "r" no sea divisible por ningun numero entre 2 y i/2
	//si completa el segundo ciclo for quiere decir que no es divisible
	//en el if chequea que i > 1 porque ni el 0 ni el 1 son primos 
	cout << "Los numeros primos entre " << l << " y " << r << " son: \n";
	for (int i = l; i <= r; i++)
	{
		int j;
		for (j = 2; (j <= i/2) && (i%j != 0); j++);
		if ((j > i/2) && (i > 1)) cout << i << " ";
	}
	cout << endl;

	//equivalente con ciclo while
	cout << "\n(ciclo while) Los numeros primos entre " << l << " y " << r << " son: \n";
	for (int i = l; i <= r; i++)
	{
		int j = 2;
		while ((j <= i/2) && (i%j != 0))
			j++;
		
		if ((j > i/2) && (i > 1)) cout << i << " ";
	}
	cout << endl;
	


	cout << "Programa terminado exitosamente !!" << endl;
	return EXIT_SUCCESS;

}
